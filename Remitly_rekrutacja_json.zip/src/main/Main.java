package main;

public class Main {
    public static void main(String[] args) throws PolicyMissing {
        ReadJson readjson = new ReadJson();
        if(readjson.check_asterix("D:\\Programy\\Intellij-programy\\Remitly_rekrutacja_json\\test1_false.json")){
            System.out.println("TRUE: resource field contains sth different than single '*'");
        }
        else{
            System.out.println("FALSE: resource field contains '*'");
        }

    }
}