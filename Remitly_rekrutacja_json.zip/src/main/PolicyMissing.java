package main;

public class PolicyMissing extends Exception{
    public PolicyMissing(String str){
        super(str);
    }
}
