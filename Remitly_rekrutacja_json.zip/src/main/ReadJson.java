package main;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Pattern;

public class ReadJson {
    public boolean check_asterix(String fileName) throws PolicyMissing {
        JSONParser parser = new JSONParser();
        Pattern pattern = Pattern.compile("[\\w+=,.@-]+");
        String resource="";

        try {
            Object obj = parser.parse(new FileReader(fileName));
            JSONObject jsonObject =  (JSONObject) obj;
            String policyname = (String) jsonObject.get("PolicyName");
            JSONObject policydocument = (JSONObject) jsonObject.get("PolicyDocument");

            if(policyname == null){
                throw new PolicyMissing("PolicyName field missing");
            }
            if(policyname.length() < 1 || policyname.length() > 128 ){
                throw new PolicyMissing("Wrog length od PolicyName field");
            }
            if(!pattern.matcher(policyname).matches()){
                throw new PolicyMissing("PolicyName does not match the pattern");
            }
            if(policydocument == null){
                throw new PolicyMissing("PolicyDocument field missing");
            }

            JSONArray statementArr = (JSONArray) policydocument.get("Statement");
            JSONObject statement = (JSONObject) statementArr.get(0);
            resource = (String) statement.get("Resource");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
            throw new RuntimeException(e);
        } catch (PolicyMissing e) {
            throw new PolicyMissing(e.getMessage());
        }

        if(resource.equals("*")){
            return false;
        }

        return true;
    }
}
