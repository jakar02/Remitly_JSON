package test;

import main.PolicyMissing;
import main.ReadJson;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ReadJsonTest{
    @Test
    public void check_asterix_test1_false() throws PolicyMissing{
        ReadJson readjson = new ReadJson();
        boolean value1 = readjson.check_asterix("D:\\Programy\\Intellij-programy\\Remitly_rekrutacja_json\\test1_false.json");
        assertFalse(value1);
    }

    @Test
    public void check_asterix_test2_true() throws PolicyMissing{
        ReadJson readjson = new ReadJson();
        boolean value2 = readjson.check_asterix("D:\\Programy\\Intellij-programy\\Remitly_rekrutacja_json\\test2_true.json");
        assertTrue(value2);
    }

    @Test
    public void check_asterix_test3_true() throws PolicyMissing{
        ReadJson readjson = new ReadJson();
        boolean value3 = readjson.check_asterix("D:\\Programy\\Intellij-programy\\Remitly_rekrutacja_json\\test3_true.json");
        assertTrue(value3);
    }

    @Test
    public void check_asterix_test4_bad_format() throws PolicyMissing{
        ReadJson readjson = new ReadJson();
        assertThrows(PolicyMissing.class, () -> readjson.check_asterix("D:\\Programy\\Intellij-programy\\Remitly_rekrutacja_json\\test4_bad_format.json"));
    }

    @Test
    public void check_asterix_test5_bad_format() throws PolicyMissing{
        ReadJson readjson = new ReadJson();
        assertThrows(PolicyMissing.class, () -> readjson.check_asterix("D:\\Programy\\Intellij-programy\\Remitly_rekrutacja_json\\test5_bad_format.json"));
    }
}